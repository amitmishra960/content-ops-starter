import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'screens/home_screen.dart';
import 'screens/pin_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(const GSTTrackerApp());
}

class GSTTrackerApp extends StatefulWidget {
  const GSTTrackerApp({super.key});
  @override
  State<GSTTrackerApp> createState() => _GSTTrackerAppState();
}

class _GSTTrackerAppState extends State<GSTTrackerApp> {
  bool _isDark = true;
  bool _hasPIN = false;
  bool _authenticated = false;

  @override
  void initState() {
    super.initState();
    _loadPrefs();
  }

  Future<void> _loadPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _isDark = prefs.getBool('darkMode') ?? true;
      _hasPIN = (prefs.getString('pin') ?? '').isNotEmpty;
      _authenticated = !_hasPIN;
    });
  }

  void _onAuthenticated() => setState(() => _authenticated = true);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'GST Return Tracker',
      debugShowCheckedModeBanner: false,
      themeMode: _isDark ? ThemeMode.dark : ThemeMode.light,
      theme: _buildLightTheme(),
      darkTheme: _buildDarkTheme(),
      home: _authenticated
          ? HomeScreen(
              isDark: _isDark,
              onThemeToggle: () async {
                final prefs = await SharedPreferences.getInstance();
                setState(() => _isDark = !_isDark);
                await prefs.setBool('darkMode', _isDark);
              },
            )
          : PinScreen(onSuccess: _onAuthenticated),
    );
  }

  ThemeData _buildDarkTheme() {
    const primary = Color(0xFF4F8EF7);
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      colorScheme: ColorScheme.dark(
        primary: primary,
        secondary: const Color(0xFF7C5CFC),
        surface: const Color(0xFF1A1D27),
        surfaceContainerHighest: const Color(0xFF22263A),
        outline: const Color(0xFF2E3354),
        onSurface: const Color(0xFFE2E8F0),
        error: const Color(0xFFEF4444),
      ),
      scaffoldBackgroundColor: const Color(0xFF0F1117),
      cardColor: const Color(0xFF1A1D27),
      appBarTheme: const AppBarTheme(
        backgroundColor: Color(0xFF1A1D27),
        foregroundColor: Color(0xFFE2E8F0),
        elevation: 0,
      ),
      navigationBarTheme: const NavigationBarThemeData(
        backgroundColor: Color(0xFF1A1D27),
        indicatorColor: Color(0xFF4F8EF7),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: const Color(0xFF22263A),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: Color(0xFF2E3354)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: Color(0xFF2E3354)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: primary, width: 2),
        ),
        labelStyle: const TextStyle(color: Color(0xFF94A3B8)),
        hintStyle: const TextStyle(color: Color(0xFF64748B)),
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: primary,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        ),
      ),
      chipTheme: ChipThemeData(
        backgroundColor: const Color(0xFF22263A),
        selectedColor: primary,
        labelStyle: const TextStyle(fontSize: 12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      ),
      fontFamily: 'Roboto',
    );
  }

  ThemeData _buildLightTheme() {
    const primary = Color(0xFF2563EB);
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.light,
      colorScheme: ColorScheme.light(
        primary: primary,
        secondary: const Color(0xFF7C3AED),
        surface: Colors.white,
        surfaceContainerHighest: const Color(0xFFF8FAFC),
        outline: const Color(0xFFE2E8F0),
        onSurface: const Color(0xFF1E293B),
      ),
      scaffoldBackgroundColor: const Color(0xFFF1F5F9),
      cardColor: Colors.white,
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.white,
        foregroundColor: Color(0xFF1E293B),
        elevation: 0,
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: const Color(0xFFF8FAFC),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: Color(0xFFE2E8F0)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: Color(0xFFE2E8F0)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: primary, width: 2),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      ),
      fontFamily: 'Roboto',
    );
  }
}
