import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/client.dart';
import '../models/gst_return.dart';

class DatabaseService {
  static Database? _db;
  static const _version = 1;

  static Future<Database> get db async {
    _db ??= await _init();
    return _db!;
  }

  static Future<Database> _init() async {
    final path = join(await getDatabasesPath(), 'gst_tracker.db');
    return await openDatabase(
      path,
      version: _version,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE clients (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            gstin TEXT NOT NULL,
            tradeName TEXT,
            businessType TEXT,
            mobile TEXT,
            email TEXT,
            pan TEXT,
            state TEXT,
            registrationDate TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE filings (
            dbKey TEXT PRIMARY KEY,
            clientId TEXT NOT NULL,
            returnType TEXT NOT NULL,
            dueDate TEXT NOT NULL,
            status TEXT NOT NULL,
            filingDate TEXT,
            remarks TEXT
          )
        ''');
        // Insert sample data
        await _insertSampleData(db);
      },
    );
  }

  static Future<void> _insertSampleData(Database db) async {
    final samples = [
      {
        'id': 'c1', 'name': 'ABC Traders', 'gstin': '27AABCT1234A1Z5',
        'tradeName': 'ABC Textiles', 'businessType': 'Regular',
        'mobile': '9876543210', 'email': 'abc@traders.com',
        'pan': 'AABCT1234A', 'state': 'others', 'registrationDate': '2018-07-01'
      },
      {
        'id': 'c2', 'name': 'XYZ Enterprises', 'gstin': '29AABCX5678B1Z3',
        'tradeName': 'XYZ Exports', 'businessType': 'QRMP',
        'mobile': '9123456789', 'email': 'xyz@enterprise.com',
        'pan': 'AABCX5678B', 'state': 'special', 'registrationDate': '2019-04-01'
      },
      {
        'id': 'c3', 'name': 'Sharma Medicals', 'gstin': '07AAQCS9012C1Z2',
        'tradeName': 'Sharma Medical Store', 'businessType': 'Composition',
        'mobile': '9988776655', 'email': 'sharma@med.com',
        'pan': 'AAQCS9012C', 'state': 'others', 'registrationDate': '2020-01-15'
      },
    ];
    for (final s in samples) {
      await db.insert('clients', s);
    }
  }

  // ---- CLIENTS ----
  static Future<List<Client>> getClients() async {
    final d = await db;
    final maps = await d.query('clients', orderBy: 'name ASC');
    return maps.map(Client.fromMap).toList();
  }

  static Future<void> insertClient(Client c) async {
    final d = await db;
    await d.insert('clients', c.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  static Future<void> updateClient(Client c) async {
    final d = await db;
    await d.update('clients', c.toMap(), where: 'id = ?', whereArgs: [c.id]);
  }

  static Future<void> deleteClient(String id) async {
    final d = await db;
    await d.delete('clients', where: 'id = ?', whereArgs: [id]);
    await d.delete('filings', where: 'clientId = ?', whereArgs: [id]);
  }

  // ---- FILINGS ----
  static Future<GstReturn?> getFiling(String clientId, String returnType, DateTime dueDate) async {
    final d = await db;
    final key = '${clientId}_${returnType}_${dueDate.year}_${dueDate.month}';
    final maps = await d.query('filings', where: 'dbKey = ?', whereArgs: [key]);
    if (maps.isEmpty) return null;
    return GstReturn.fromMap(maps.first);
  }

  static Future<void> saveFiling(GstReturn r) async {
    final d = await db;
    await d.insert('filings', {
      'dbKey': r.dbKey,
      ...r.toMap(),
    }, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  static Future<List<GstReturn>> getAllFilings() async {
    final d = await db;
    final maps = await d.query('filings');
    return maps.map(GstReturn.fromMap).toList();
  }
}
