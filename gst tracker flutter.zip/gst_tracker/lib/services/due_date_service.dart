import 'package:gst_tracker/models/client.dart';
import 'package:gst_tracker/models/gst_return.dart';

class DueDateService {
  static List<GstReturn> getReturnsForClient(Client client, {DateTime? ref}) {
    final now = ref ?? DateTime.now();
    final year = now.year;
    final month = now.month; // 1-indexed

    final returns = <GstReturn>[];

    void add(String type, DateTime due) {
      returns.add(GstReturn(
        clientId: client.id,
        returnType: type,
        dueDate: due,
      ));
    }

    // Financial year start
    final fyStart = month >= 4 ? year : year - 1;

    // Quarter info (0=Q1 Apr-Jun, 1=Q2 Jul-Sep, 2=Q3 Oct-Dec, 3=Q4 Jan-Mar)
    final qIndex = ((month - 1) % 12) ~/ 3; // in 1-12 month
    // months: Q1=4,5,6 Q2=7,8,9 Q3=10,11,12 Q4=1,2,3
    final qMonthInQ = (month <= 3)
        ? ((month - 1) % 3)
        : ((month - 4) % 3); // 0,1,2

    // GSTR-1 (Regular) - 11th of next month
    if (client.businessType == 'Regular') {
      final due = _addMonth(year, month, 11);
      add('GSTR-1', due);
    }

    // GSTR-1 IFF (QRMP) - 13th of next month (for first 2 months of quarter)
    if (client.businessType == 'QRMP') {
      if (qMonthInQ != 2) {
        add('GSTR-1 IFF', _addMonth(year, month, 13));
      } else {
        add('GSTR-1', _addMonth(year, month, 11));
      }
    }

    // GSTR-3B (Regular) - 20th of next month
    if (client.businessType == 'Regular') {
      add('GSTR-3B', _addMonth(year, month, 20));
    }

    // GSTR-3B Quarterly (QRMP) - 22nd/24th after quarter end
    if (client.businessType == 'QRMP' && qMonthInQ == 2) {
      final dueDay = client.state == 'special' ? 24 : 22;
      add('GSTR-3B (Q)', _addMonth(year, month, dueDay));
    }

    // GSTR-7 & GSTR-8 - 10th of next month (Regular only)
    if (client.businessType == 'Regular') {
      add('GSTR-7', _addMonth(year, month, 10));
      add('GSTR-8', _addMonth(year, month, 10));
    }

    // Composition scheme returns
    if (client.businessType == 'Composition') {
      // CMP-08 - 18th after quarter end
      if (qMonthInQ == 2) {
        add('CMP-08', _addMonth(year, month, 18));
      }
      // GSTR-4 - 30 April next FY
      add('GSTR-4', DateTime(fyStart + 1, 4, 30));
    }

    // GSTR-9 & GSTR-9C - 31 Dec next FY (not for Composition)
    if (client.businessType != 'Composition') {
      add('GSTR-9', DateTime(fyStart + 1, 12, 31));
    }
    if (client.businessType == 'Regular') {
      add('GSTR-9C', DateTime(fyStart + 1, 12, 31));
    }

    return returns;
  }

  static DateTime _addMonth(int year, int month, int day) {
    int nextMonth = month + 1;
    int nextYear = year;
    if (nextMonth > 12) {
      nextMonth = 1;
      nextYear++;
    }
    return DateTime(nextYear, nextMonth, day);
  }

  // Get all returns across all clients for a given month
  static List<GstReturn> getReturnsForMonth(
      List<Client> clients, int year, int month) {
    final results = <GstReturn>[];
    for (final client in clients) {
      final returns = getReturnsForClient(client);
      results.addAll(returns.where(
          (r) => r.dueDate.year == year && r.dueDate.month == month));
    }
    return results;
  }
}
