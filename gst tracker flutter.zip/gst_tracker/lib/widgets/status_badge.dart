// status_badge.dart
import 'package:flutter/material.dart';
import '../models/gst_return.dart';

class StatusBadge extends StatelessWidget {
  final GstReturn gstReturn;
  const StatusBadge({super.key, required this.gstReturn});

  @override
  Widget build(BuildContext context) {
    Color color;
    String label;
    final r = gstReturn;

    if (r.isOverdue) {
      color = const Color(0xFFEF4444); label = '● Overdue';
    } else if (r.status == FilingStatus.filed) {
      color = const Color(0xFF22C55E); label = '✓ Filed';
    } else if (r.status == FilingStatus.inProgress) {
      color = const Color(0xFF4F8EF7); label = '◎ In Progress';
    } else if (r.status == FilingStatus.notApplicable) {
      color = const Color(0xFF6B7280); label = '— N/A';
    } else if (r.isDueSoon) {
      color = const Color(0xFFF59E0B); label = '◐ Due Soon';
    } else {
      color = const Color(0xFFF59E0B); label = '○ Pending';
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Text(label, style: TextStyle(fontSize: 10, color: color, fontWeight: FontWeight.w700, fontFamily: 'monospace')),
    );
  }
}
