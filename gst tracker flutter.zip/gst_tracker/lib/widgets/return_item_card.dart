import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/client.dart';
import '../models/gst_return.dart';
import '../services/database_service.dart';
import 'status_badge.dart';

class ReturnItemCard extends StatelessWidget {
  final GstReturn gstReturn;
  final Client client;
  final VoidCallback onUpdate;
  const ReturnItemCard({super.key, required this.gstReturn, required this.client, required this.onUpdate});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final r = gstReturn;
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: scheme.primary.withOpacity(0.1),
                borderRadius: BorderRadius.circular(6),
              ),
              child: Text(r.returnType,
                  style: TextStyle(fontFamily: 'monospace', fontSize: 11, fontWeight: FontWeight.w800, color: scheme.primary)),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(client.name, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                Text('Due: ${DateFormat('dd MMM yyyy').format(r.dueDate)}',
                    style: TextStyle(fontSize: 11, color: scheme.onSurface.withOpacity(0.5))),
                if (r.remarks.isNotEmpty)
                  Text(r.remarks, style: TextStyle(fontSize: 10, color: scheme.onSurface.withOpacity(0.4)),
                      maxLines: 1, overflow: TextOverflow.ellipsis),
              ]),
            ),
            StatusBadge(gstReturn: r),
            const SizedBox(width: 6),
            IconButton(
              icon: const Icon(Icons.edit_outlined, size: 16),
              onPressed: () => _showUpdateSheet(context),
              padding: EdgeInsets.zero,
              constraints: const BoxConstraints(minWidth: 28, minHeight: 28),
            ),
          ],
        ),
      ),
    );
  }

  void _showUpdateSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Theme.of(context).cardColor,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => _UpdateSheet(gstReturn: gstReturn, client: client, onSaved: onUpdate),
    );
  }
}

class _UpdateSheet extends StatefulWidget {
  final GstReturn gstReturn;
  final Client client;
  final VoidCallback onSaved;
  const _UpdateSheet({required this.gstReturn, required this.client, required this.onSaved});
  @override
  State<_UpdateSheet> createState() => _UpdateSheetState();
}

class _UpdateSheetState extends State<_UpdateSheet> {
  late FilingStatus _status;
  DateTime? _filingDate;
  final _remarks = TextEditingController();

  @override
  void initState() {
    super.initState();
    _status = widget.gstReturn.status;
    _filingDate = widget.gstReturn.filingDate;
    _remarks.text = widget.gstReturn.remarks;
  }

  @override
  void dispose() {
    _remarks.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    widget.gstReturn.status = _status;
    widget.gstReturn.filingDate = _filingDate;
    widget.gstReturn.remarks = _remarks.text;
    await DatabaseService.saveFiling(widget.gstReturn);
    if (mounted) Navigator.pop(context);
    widget.onSaved();
  }

  Future<void> _sendWhatsApp() async {
    final c = widget.client;
    final r = widget.gstReturn;
    final msg = Uri.encodeComponent(
      'Dear ${c.name},\n\n'
      'Reminder: Your ${r.returnType} return is due on '
      '${DateFormat('dd MMM yyyy').format(r.dueDate)}.\n\n'
      'Kindly share the necessary documents at the earliest.\n\n'
      'Thank you.',
    );
    final url = Uri.parse('https://wa.me/${c.mobile}?text=$msg');
    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    final r = widget.gstReturn;
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${r.returnType} — ${widget.client.name}',
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
              Text('Due: ${DateFormat('dd MMM yyyy').format(r.dueDate)}',
                  style: TextStyle(fontSize: 12, color: scheme.onSurface.withOpacity(0.5))),
            ])),
            IconButton(icon: const Icon(Icons.close), onPressed: () => Navigator.pop(context)),
          ]),
          const SizedBox(height: 14),
          const Text('Status', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w500)),
          const SizedBox(height: 6),
          Wrap(spacing: 8, children: FilingStatus.values.map((s) => ChoiceChip(
            label: Text(_statusLabel(s)),
            selected: _status == s,
            showCheckmark: false,
            onSelected: (_) => setState(() => _status = s),
          )).toList()),
          const SizedBox(height: 12),
          InkWell(
            onTap: () async {
              final d = await showDatePicker(
                context: context,
                initialDate: _filingDate ?? DateTime.now(),
                firstDate: DateTime(2020),
                lastDate: DateTime.now(),
              );
              if (d != null) setState(() => _filingDate = d);
            },
            child: InputDecorator(
              decoration: const InputDecoration(labelText: 'Filing Date (if filed)'),
              child: Text(
                _filingDate != null ? DateFormat('dd MMM yyyy').format(_filingDate!) : 'Select date',
                style: TextStyle(color: _filingDate != null ? null : scheme.outline),
              ),
            ),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _remarks,
            decoration: const InputDecoration(labelText: 'Remarks', isDense: true),
            maxLines: 2,
          ),
          const SizedBox(height: 16),
          Row(children: [
            Expanded(child: ElevatedButton(onPressed: _save, child: const Text('Save Status'))),
            const SizedBox(width: 8),
            OutlinedButton.icon(
              onPressed: _sendWhatsApp,
              icon: const Text('💬'),
              label: const Text('WhatsApp'),
            ),
          ]),
        ]),
      ),
    );
  }

  String _statusLabel(FilingStatus s) {
    switch (s) {
      case FilingStatus.pending: return 'Pending';
      case FilingStatus.inProgress: return 'In Progress';
      case FilingStatus.filed: return 'Filed';
      case FilingStatus.notApplicable: return 'Not Applicable';
    }
  }
}
