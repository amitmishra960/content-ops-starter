class Client {
  final String id;
  String name;
  String gstin;
  String tradeName;
  String businessType; // Regular, Composition, QRMP
  String mobile;
  String email;
  String pan;
  String state; // 'others' (22nd) or 'special' (24th)
  String registrationDate;

  Client({
    required this.id,
    required this.name,
    required this.gstin,
    this.tradeName = '',
    this.businessType = 'Regular',
    this.mobile = '',
    this.email = '',
    this.pan = '',
    this.state = 'others',
    this.registrationDate = '',
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'name': name,
    'gstin': gstin,
    'tradeName': tradeName,
    'businessType': businessType,
    'mobile': mobile,
    'email': email,
    'pan': pan,
    'state': state,
    'registrationDate': registrationDate,
  };

  factory Client.fromMap(Map<String, dynamic> m) => Client(
    id: m['id'],
    name: m['name'],
    gstin: m['gstin'],
    tradeName: m['tradeName'] ?? '',
    businessType: m['businessType'] ?? 'Regular',
    mobile: m['mobile'] ?? '',
    email: m['email'] ?? '',
    pan: m['pan'] ?? '',
    state: m['state'] ?? 'others',
    registrationDate: m['registrationDate'] ?? '',
  );
}
