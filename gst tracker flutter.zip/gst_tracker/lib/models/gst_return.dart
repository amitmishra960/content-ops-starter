enum FilingStatus { pending, inProgress, filed, notApplicable }

class GstReturn {
  final String clientId;
  final String returnType;
  final DateTime dueDate;
  FilingStatus status;
  DateTime? filingDate;
  String remarks;

  GstReturn({
    required this.clientId,
    required this.returnType,
    required this.dueDate,
    this.status = FilingStatus.pending,
    this.filingDate,
    this.remarks = '',
  });

  String get dbKey => '${clientId}_${returnType}_${dueDate.year}_${dueDate.month}';

  bool get isOverdue {
    if (status == FilingStatus.filed || status == FilingStatus.notApplicable) return false;
    return dueDate.isBefore(DateTime.now());
  }

  bool get isDueSoon {
    if (status == FilingStatus.filed || status == FilingStatus.notApplicable) return false;
    final diff = dueDate.difference(DateTime.now()).inDays;
    return diff >= 0 && diff <= 3;
  }

  Map<String, dynamic> toMap() => {
    'clientId': clientId,
    'returnType': returnType,
    'dueDate': dueDate.toIso8601String(),
    'status': status.name,
    'filingDate': filingDate?.toIso8601String(),
    'remarks': remarks,
  };

  factory GstReturn.fromMap(Map<String, dynamic> m) => GstReturn(
    clientId: m['clientId'],
    returnType: m['returnType'],
    dueDate: DateTime.parse(m['dueDate']),
    status: FilingStatus.values.firstWhere(
      (e) => e.name == m['status'],
      orElse: () => FilingStatus.pending,
    ),
    filingDate: m['filingDate'] != null ? DateTime.parse(m['filingDate']) : null,
    remarks: m['remarks'] ?? '',
  );
}
