import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/client.dart';
import '../models/gst_return.dart';
import '../services/database_service.dart';
import '../services/due_date_service.dart';
import '../widgets/status_badge.dart';
import '../widgets/return_item_card.dart';

class ClientsScreen extends StatefulWidget {
  const ClientsScreen({super.key});
  @override
  State<ClientsScreen> createState() => _ClientsScreenState();
}

class _ClientsScreenState extends State<ClientsScreen> {
  List<Client> _all = [], _filtered = [];
  final _search = TextEditingController();
  String _typeFilter = 'All';
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
    _search.addListener(_filter);
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final clients = await DatabaseService.getClients();
    setState(() {
      _all = clients;
      _loading = false;
      _filter();
    });
  }

  void _filter() {
    final q = _search.text.toLowerCase();
    setState(() {
      _filtered = _all.where((c) {
        final matchQ = q.isEmpty || c.name.toLowerCase().contains(q) || c.gstin.toLowerCase().contains(q);
        final matchType = _typeFilter == 'All' || c.businessType == _typeFilter;
        return matchQ && matchType;
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 14, 14, 8),
          child: Column(
            children: [
              TextField(
                controller: _search,
                decoration: const InputDecoration(
                  prefixIcon: Icon(Icons.search, size: 18),
                  hintText: 'Search by name or GSTIN...',
                  isDense: true,
                ),
              ),
              const SizedBox(height: 8),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: ['All', 'Regular', 'QRMP', 'Composition'].map((t) => Padding(
                    padding: const EdgeInsets.only(right: 6),
                    child: FilterChip(
                      label: Text(t),
                      selected: _typeFilter == t,
                      showCheckmark: false,
                      onSelected: (_) => setState(() { _typeFilter = t; _filter(); }),
                    ),
                  )).toList(),
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: _loading
              ? const Center(child: CircularProgressIndicator())
              : _filtered.isEmpty
                  ? Center(
                      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                        Icon(Icons.people_outline, size: 64, color: scheme.outline),
                        const SizedBox(height: 12),
                        Text('No clients found', style: TextStyle(color: scheme.outline)),
                        const SizedBox(height: 16),
                        ElevatedButton.icon(
                          onPressed: () => _showClientDialog(),
                          icon: const Icon(Icons.add, size: 16),
                          label: const Text('Add Client'),
                        ),
                      ]),
                    )
                  : RefreshIndicator(
                      onRefresh: _load,
                      child: ListView.builder(
                        padding: const EdgeInsets.fromLTRB(14, 0, 14, 80),
                        itemCount: _filtered.length,
                        itemBuilder: (context, i) => _ClientCard(
                          client: _filtered[i],
                          onEdit: () => _showClientDialog(client: _filtered[i]),
                          onDelete: () => _delete(_filtered[i]),
                          onTap: () => _openProfile(_filtered[i]),
                        ),
                      ),
                    ),
        ),
      ],
    );
  }

  Future<void> _delete(Client c) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Delete Client'),
        content: Text('Delete ${c.name}? This cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(context, true),
              child: const Text('Delete', style: TextStyle(color: Color(0xFFEF4444)))),
        ],
      ),
    );
    if (ok == true) {
      await DatabaseService.deleteClient(c.id);
      _load();
    }
  }

  void _openProfile(Client c) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => ClientProfileScreen(client: c)));
  }

  void _showClientDialog({Client? client}) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Theme.of(context).cardColor,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => ClientFormSheet(client: client, onSaved: _load),
    );
  }
}

class _ClientCard extends StatelessWidget {
  final Client client;
  final VoidCallback onEdit, onDelete, onTap;
  const _ClientCard({required this.client, required this.onEdit, required this.onDelete, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final initials = client.name.split(' ').map((w) => w.isNotEmpty ? w[0] : '').take(2).join().toUpperCase();
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Container(
                width: 44, height: 44,
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [scheme.primary, scheme.secondary]),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Center(child: Text(initials, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 14))),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(client.name, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                  Text(client.gstin, style: TextStyle(fontFamily: 'monospace', fontSize: 11, color: scheme.onSurface.withOpacity(0.5))),
                  const SizedBox(height: 4),
                  Row(children: [
                    _pill(client.businessType, scheme),
                    const SizedBox(width: 4),
                    _pill(client.state == 'special' ? 'Special (24th)' : 'Others (22nd)', scheme),
                  ]),
                ]),
              ),
              Column(children: [
                IconButton(icon: const Icon(Icons.edit_outlined, size: 18), onPressed: onEdit, padding: EdgeInsets.zero, constraints: const BoxConstraints()),
                const SizedBox(height: 8),
                IconButton(icon: const Icon(Icons.delete_outline, size: 18, color: Color(0xFFEF4444)), onPressed: onDelete, padding: EdgeInsets.zero, constraints: const BoxConstraints()),
              ]),
            ],
          ),
        ),
      ),
    );
  }

  Widget _pill(String text, ColorScheme scheme) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
    decoration: BoxDecoration(
      color: scheme.surfaceContainerHighest,
      borderRadius: BorderRadius.circular(20),
      border: Border.all(color: scheme.outline.withOpacity(0.5)),
    ),
    child: Text(text, style: TextStyle(fontSize: 10, color: scheme.onSurface.withOpacity(0.6))),
  );
}

// ---- CLIENT FORM SHEET ----
class ClientFormSheet extends StatefulWidget {
  final Client? client;
  final VoidCallback onSaved;
  const ClientFormSheet({super.key, this.client, required this.onSaved});
  @override
  State<ClientFormSheet> createState() => _ClientFormSheetState();
}

class _ClientFormSheetState extends State<ClientFormSheet> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _name, _gstin, _trade, _mobile, _email, _pan;
  String _type = 'Regular', _state = 'others';
  DateTime? _regDate;

  @override
  void initState() {
    super.initState();
    final c = widget.client;
    _name = TextEditingController(text: c?.name ?? '');
    _gstin = TextEditingController(text: c?.gstin ?? '');
    _trade = TextEditingController(text: c?.tradeName ?? '');
    _mobile = TextEditingController(text: c?.mobile ?? '');
    _email = TextEditingController(text: c?.email ?? '');
    _pan = TextEditingController(text: c?.pan ?? '');
    _type = c?.businessType ?? 'Regular';
    _state = c?.state ?? 'others';
    if (c?.registrationDate.isNotEmpty == true) {
      _regDate = DateTime.tryParse(c!.registrationDate);
    }
  }

  @override
  void dispose() {
    for (final c in [_name, _gstin, _trade, _mobile, _email, _pan]) c.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final client = Client(
      id: widget.client?.id ?? 'c${DateTime.now().millisecondsSinceEpoch}',
      name: _name.text.trim(),
      gstin: _gstin.text.trim().toUpperCase(),
      tradeName: _trade.text.trim(),
      businessType: _type,
      mobile: _mobile.text.trim(),
      email: _email.text.trim(),
      pan: _pan.text.trim().toUpperCase(),
      state: _state,
      registrationDate: _regDate != null ? DateFormat('yyyy-MM-dd').format(_regDate!) : '',
    );
    if (widget.client != null) {
      await DatabaseService.updateClient(client);
    } else {
      await DatabaseService.insertClient(client);
    }
    if (mounted) Navigator.pop(context);
    widget.onSaved();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Form(
        key: _formKey,
        child: ListView(
          shrinkWrap: true,
          padding: const EdgeInsets.all(20),
          children: [
            Row(children: [
              Text(widget.client == null ? 'Add Client' : 'Edit Client',
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
              const Spacer(),
              IconButton(icon: const Icon(Icons.close), onPressed: () => Navigator.pop(context)),
            ]),
            const SizedBox(height: 12),
            _field('Client Name *', _name, required: true),
            const SizedBox(height: 10),
            _field('GSTIN *', _gstin, required: true, caps: true, maxLen: 15),
            const SizedBox(height: 10),
            _field('Trade Name', _trade),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: _dropdown('Business Type', _type, ['Regular', 'QRMP', 'Composition'], (v) => setState(() => _type = v!))),
              const SizedBox(width: 10),
              Expanded(child: _dropdown('State Category', _state, ['others', 'special'], (v) => setState(() => _state = v!),
                  labels: {'others': 'Others (22nd)', 'special': 'Special (24th)'})),
            ]),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: _field('Mobile', _mobile, type: TextInputType.phone, maxLen: 10)),
              const SizedBox(width: 10),
              Expanded(child: _field('PAN', _pan, caps: true, maxLen: 10)),
            ]),
            const SizedBox(height: 10),
            _field('Email', _email, type: TextInputType.emailAddress),
            const SizedBox(height: 10),
            InkWell(
              onTap: () async {
                final d = await showDatePicker(
                  context: context,
                  initialDate: _regDate ?? DateTime(2018),
                  firstDate: DateTime(2017),
                  lastDate: DateTime.now(),
                );
                if (d != null) setState(() => _regDate = d);
              },
              child: InputDecorator(
                decoration: const InputDecoration(labelText: 'Registration Date'),
                child: Text(_regDate != null ? DateFormat('dd MMM yyyy').format(_regDate!) : 'Select date',
                    style: TextStyle(color: _regDate != null ? null : Theme.of(context).colorScheme.outline)),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(onPressed: _save, child: Text(widget.client == null ? 'Add Client' : 'Save Changes')),
          ],
        ),
      ),
    );
  }

  Widget _field(String label, TextEditingController ctrl, {
    bool required = false, bool caps = false, TextInputType? type, int? maxLen
  }) => TextFormField(
    controller: ctrl,
    decoration: InputDecoration(labelText: label),
    textCapitalization: caps ? TextCapitalization.characters : TextCapitalization.words,
    keyboardType: type,
    maxLength: maxLen,
    buildCounter: (_,{required currentLength, required isFocused, maxLength}) => null,
    validator: required ? (v) => (v?.trim().isEmpty ?? true) ? '$label is required' : null : null,
  );

  Widget _dropdown(String label, String val, List<String> items, ValueChanged<String?> onChanged, {Map<String,String>? labels}) =>
    DropdownButtonFormField<String>(
      value: val,
      decoration: InputDecoration(labelText: label),
      items: items.map((v) => DropdownMenuItem(value: v, child: Text(labels?[v] ?? v, style: const TextStyle(fontSize: 13)))).toList(),
      onChanged: onChanged,
    );
}

// ---- CLIENT PROFILE ----
class ClientProfileScreen extends StatefulWidget {
  final Client client;
  const ClientProfileScreen({super.key, required this.client});
  @override
  State<ClientProfileScreen> createState() => _ClientProfileScreenState();
}

class _ClientProfileScreenState extends State<ClientProfileScreen> {
  List<GstReturn> _returns = [];
  Map<String, GstReturn> _filingMap = {};
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final allFilings = await DatabaseService.getAllFilings();
    setState(() {
      _filingMap = {for (var f in allFilings) f.dbKey: f};
      _returns = DueDateService.getReturnsForClient(widget.client).map((r) {
        final f = _filingMap[r.dbKey];
        if (f != null) { r.status = f.status; r.filingDate = f.filingDate; r.remarks = f.remarks; }
        return r;
      }).toList();
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final c = widget.client;
    return Scaffold(
      appBar: AppBar(title: Text(c.name)),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(14),
              children: [
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _infoRow('GSTIN', c.gstin, mono: true),
                        _infoRow('Trade Name', c.tradeName),
                        _infoRow('Business Type', c.businessType),
                        _infoRow('Mobile', c.mobile),
                        _infoRow('Email', c.email),
                        _infoRow('PAN', c.pan, mono: true),
                        _infoRow('State', c.state == 'special' ? 'Special Category (24th)' : 'Others (22nd)'),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                Text('Current Period Returns', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: scheme.onSurface.withOpacity(0.5))),
                const SizedBox(height: 8),
                ..._returns.map((r) => Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: ReturnItemCard(gstReturn: r, client: c, onUpdate: _load),
                )),
              ],
            ),
    );
  }

  Widget _infoRow(String label, String value, {bool mono = false}) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(width: 110, child: Text(label, style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSurface.withOpacity(0.4)))),
        Expanded(child: Text(value.isEmpty ? '—' : value, style: TextStyle(fontSize: 13, fontFamily: mono ? 'monospace' : null))),
      ],
    ),
  );
}
