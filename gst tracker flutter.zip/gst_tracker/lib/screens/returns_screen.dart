import 'package:flutter/material.dart';
import '../models/client.dart';
import '../models/gst_return.dart';
import '../services/database_service.dart';
import '../services/due_date_service.dart';
import '../widgets/return_item_card.dart';

class ReturnsScreen extends StatefulWidget {
  const ReturnsScreen({super.key});
  @override
  State<ReturnsScreen> createState() => _ReturnsScreenState();
}

class _ReturnsScreenState extends State<ReturnsScreen> {
  List<_Item> _all = [];
  String _filter = 'all';
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final clients = await DatabaseService.getClients();
    final allFilings = await DatabaseService.getAllFilings();
    final filingMap = {for (var f in allFilings) f.dbKey: f};
    final items = <_Item>[];
    for (final c in clients) {
      for (final r in DueDateService.getReturnsForClient(c)) {
        final f = filingMap[r.dbKey];
        if (f != null) { r.status = f.status; r.filingDate = f.filingDate; r.remarks = f.remarks; }
        items.add(_Item(client: c, gstReturn: r));
      }
    }
    setState(() { _all = items; _loading = false; });
  }

  List<_Item> get _filtered {
    return _all.where((item) {
      final r = item.gstReturn;
      switch (_filter) {
        case 'Pending': return r.status == FilingStatus.pending;
        case 'Filed': return r.status == FilingStatus.filed;
        case 'In Progress': return r.status == FilingStatus.inProgress;
        case 'overdue': return r.isOverdue;
        default: return true;
      }
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    // Group by return type
    final grouped = <String, List<_Item>>{};
    for (final item in _filtered) {
      grouped.putIfAbsent(item.gstReturn.returnType, () => []).add(item);
    }

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 14, 14, 8),
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: {
                'all': 'All', 'Pending': 'Pending', 'Filed': 'Filed',
                'In Progress': 'In Progress', 'overdue': 'Overdue'
              }.entries.map((e) => Padding(
                padding: const EdgeInsets.only(right: 6),
                child: FilterChip(
                  label: Text(e.value),
                  selected: _filter == e.key,
                  showCheckmark: false,
                  onSelected: (_) => setState(() => _filter = e.key),
                ),
              )).toList(),
            ),
          ),
        ),
        Expanded(
          child: _loading
              ? const Center(child: CircularProgressIndicator())
              : grouped.isEmpty
                  ? Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(Icons.assignment_outlined, size: 64, color: Theme.of(context).colorScheme.outline),
                      const SizedBox(height: 12),
                      Text('No returns match this filter', style: TextStyle(color: Theme.of(context).colorScheme.outline)),
                    ]))
                  : RefreshIndicator(
                      onRefresh: _load,
                      child: ListView(
                        padding: const EdgeInsets.fromLTRB(14, 0, 14, 80),
                        children: grouped.entries.map((e) => Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.symmetric(vertical: 8),
                              child: Row(children: [
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                                  decoration: BoxDecoration(
                                    color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  child: Text('${e.key}  (${e.value.length})',
                                      style: TextStyle(fontFamily: 'monospace', fontSize: 11,
                                          fontWeight: FontWeight.w700, color: Theme.of(context).colorScheme.primary)),
                                ),
                              ]),
                            ),
                            ...e.value.map((item) => Padding(
                              padding: const EdgeInsets.only(bottom: 8),
                              child: ReturnItemCard(gstReturn: item.gstReturn, client: item.client, onUpdate: _load),
                            )),
                          ],
                        )).toList(),
                      ),
                    ),
        ),
      ],
    );
  }
}

class _Item {
  final Client client;
  final GstReturn gstReturn;
  _Item({required this.client, required this.gstReturn});
}
