import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:local_auth/local_auth.dart';

class PinScreen extends StatefulWidget {
  final VoidCallback onSuccess;
  const PinScreen({super.key, required this.onSuccess});
  @override
  State<PinScreen> createState() => _PinScreenState();
}

class _PinScreenState extends State<PinScreen> {
  String _input = '';
  String _savedPin = '';
  String _error = '';
  final _auth = LocalAuthentication();

  @override
  void initState() {
    super.initState();
    _loadPin();
  }

  Future<void> _loadPin() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() => _savedPin = prefs.getString('pin') ?? '');
    if (_savedPin.isNotEmpty) {
      _tryBiometric();
    }
  }

  Future<void> _tryBiometric() async {
    try {
      final canAuth = await _auth.canCheckBiometrics;
      if (canAuth) {
        final ok = await _auth.authenticate(
          localizedReason: 'Authenticate to access GST Tracker',
          options: const AuthenticationOptions(biometricOnly: true),
        );
        if (ok && mounted) widget.onSuccess();
      }
    } catch (_) {}
  }

  void _press(String d) {
    if (_input.length >= 4) return;
    setState(() {
      _input += d;
      _error = '';
    });
    if (_input.length == 4) _verify();
  }

  void _backspace() => setState(() {
    if (_input.isNotEmpty) _input = _input.substring(0, _input.length - 1);
    _error = '';
  });

  Future<void> _verify() async {
    if (_savedPin.isEmpty) {
      // First time: set PIN
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('pin', _input);
      widget.onSuccess();
    } else {
      if (_input == _savedPin) {
        widget.onSuccess();
      } else {
        setState(() { _input = ''; _error = 'Incorrect PIN. Try again.'; });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final isFirst = _savedPin.isEmpty;
    return Scaffold(
      backgroundColor: const Color(0xFF0F1117),
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 72, height: 72,
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [scheme.primary, const Color(0xFF7C5CFC)]),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Icon(Icons.receipt_long, color: Colors.white, size: 36),
              ),
              const SizedBox(height: 20),
              const Text('GST Return Tracker', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              Text(isFirst ? 'Set a 4-digit PIN' : 'Enter your PIN',
                  style: const TextStyle(color: Color(0xFF94A3B8), fontSize: 14)),
              const SizedBox(height: 32),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(4, (i) => Container(
                  margin: const EdgeInsets.symmetric(horizontal: 8),
                  width: 14, height: 14,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: i < _input.length ? scheme.primary : const Color(0xFF2E3354),
                  ),
                )),
              ),
              if (_error.isNotEmpty) ...[
                const SizedBox(height: 16),
                Text(_error, style: const TextStyle(color: Color(0xFFEF4444), fontSize: 13)),
              ],
              const SizedBox(height: 32),
              // Numpad
              SizedBox(
                width: 260,
                child: GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 1.5),
                  itemCount: 12,
                  itemBuilder: (context, i) {
                    if (i == 9) return const SizedBox();
                    if (i == 10) return _numBtn('0');
                    if (i == 11) return _iconBtn(Icons.backspace_outlined, _backspace);
                    return _numBtn('${i + 1}');
                  },
                ),
              ),
              if (!isFirst) ...[
                const SizedBox(height: 20),
                TextButton.icon(
                  onPressed: _tryBiometric,
                  icon: const Icon(Icons.fingerprint, color: Color(0xFF94A3B8)),
                  label: const Text('Use Biometric', style: TextStyle(color: Color(0xFF94A3B8))),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _numBtn(String n) => InkWell(
    onTap: () => _press(n),
    borderRadius: BorderRadius.circular(50),
    child: Container(
      decoration: BoxDecoration(
        color: const Color(0xFF1A1D27),
        shape: BoxShape.circle,
        border: Border.all(color: const Color(0xFF2E3354)),
      ),
      child: Center(child: Text(n, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w500))),
    ),
  );

  Widget _iconBtn(IconData icon, VoidCallback onTap) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(50),
    child: Container(
      decoration: const BoxDecoration(shape: BoxShape.circle),
      child: Center(child: Icon(icon, color: const Color(0xFF94A3B8), size: 22)),
    ),
  );
}
