import 'package:flutter/material.dart';
import 'dashboard_screen.dart';
import 'clients_screen.dart';
import 'returns_screen.dart';
import 'calendar_screen.dart';
import 'notifications_screen.dart';
import 'reports_screen.dart';

class HomeScreen extends StatefulWidget {
  final bool isDark;
  final VoidCallback onThemeToggle;
  const HomeScreen({super.key, required this.isDark, required this.onThemeToggle});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _index = 0;

  final _titles = ['Dashboard', 'Clients', 'Returns', 'Calendar', 'Alerts', 'Reports'];
  final _icons = [Icons.dashboard_outlined, Icons.people_outline, Icons.assignment_outlined,
    Icons.calendar_today_outlined, Icons.notifications_outlined, Icons.summarize_outlined];
  final _activeIcons = [Icons.dashboard, Icons.people, Icons.assignment,
    Icons.calendar_today, Icons.notifications, Icons.summarize];

  late List<Widget> _screens;

  @override
  void initState() {
    super.initState();
    _screens = [
      const DashboardScreen(),
      const ClientsScreen(),
      const ReturnsScreen(),
      const CalendarScreen(),
      const NotificationsScreen(),
      const ReportsScreen(),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        leading: Padding(
          padding: const EdgeInsets.all(10),
          child: Container(
            decoration: BoxDecoration(
              color: scheme.primary,
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(Icons.receipt_long, color: Colors.white, size: 20),
          ),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(_titles[_index], style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
            Text('GST Return Tracker', style: TextStyle(fontSize: 11, color: scheme.onSurface.withOpacity(0.5))),
          ],
        ),
        actions: [
          IconButton(
            icon: Icon(widget.isDark ? Icons.light_mode_outlined : Icons.dark_mode_outlined),
            onPressed: widget.onThemeToggle,
            tooltip: 'Toggle Theme',
          ),
          if (_index == 1)
            IconButton(
              icon: const Icon(Icons.person_add_outlined),
              onPressed: () => Navigator.pushNamed(context, '/add-client'),
              tooltip: 'Add Client',
            ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Divider(height: 1, color: scheme.outline.withOpacity(0.5)),
        ),
      ),
      body: IndexedStack(index: _index, children: _screens),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        labelBehavior: NavigationDestinationLabelBehavior.onlyShowSelected,
        destinations: List.generate(6, (i) => NavigationDestination(
          icon: Icon(_icons[i]),
          selectedIcon: Icon(_activeIcons[i]),
          label: _titles[i],
        )),
      ),
    );
  }
}
