import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/client.dart';
import '../models/gst_return.dart';
import '../services/database_service.dart';
import '../services/due_date_service.dart';

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});
  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  int _month = DateTime.now().month;
  int _year = DateTime.now().year;
  String _reportType = 'pending';
  List<Client> _clients = [];
  Map<String, GstReturn> _filingMap = {};
  bool _loading = false;
  bool _generated = false;

  final _months = ['January','February','March','April','May','June',
    'July','August','September','October','November','December'];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final clients = await DatabaseService.getClients();
    final allFilings = await DatabaseService.getAllFilings();
    setState(() {
      _clients = clients;
      _filingMap = {for (var f in allFilings) f.dbKey: f};
    });
  }

  List<_ReportItem> _buildItems() {
    final items = <_ReportItem>[];
    for (final c in _clients) {
      for (final r in DueDateService.getReturnsForClient(c)) {
        if (r.dueDate.month != _month || r.dueDate.year != _year) continue;
        final f = _filingMap[r.dbKey];
        if (f != null) { r.status = f.status; r.filingDate = f.filingDate; r.remarks = f.remarks; }
        items.add(_ReportItem(client: c, gstReturn: r));
      }
    }
    return items;
  }

  void _generate() {
    setState(() { _loading = true; });
    Future.delayed(const Duration(milliseconds: 300), () {
      setState(() { _loading = false; _generated = true; });
    });
  }

  String _exportCSV() {
    final items = _buildItems();
    final buf = StringBuffer();
    buf.writeln('Client Name,GSTIN,Business Type,Return Type,Due Date,Status,Filing Date,Remarks');
    for (final item in items) {
      final r = item.gstReturn;
      buf.writeln('"${item.client.name}","${item.client.gstin}","${item.client.businessType}",'
          '"${r.returnType}","${DateFormat('yyyy-MM-dd').format(r.dueDate)}",'
          '"${r.status.name}","${r.filingDate != null ? DateFormat('yyyy-MM-dd').format(r.filingDate!) : ''}","${r.remarks}"');
    }
    return buf.toString();
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final items = _generated ? _buildItems() : <_ReportItem>[];
    final filed = items.where((i) => i.gstReturn.status == FilingStatus.filed).length;
    final pending = items.where((i) => i.gstReturn.status != FilingStatus.filed && !i.gstReturn.isOverdue).length;
    final overdue = items.where((i) => i.gstReturn.isOverdue).length;

    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        // Filters
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Generate Report', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: scheme.onSurface.withOpacity(0.5))),
                const SizedBox(height: 12),
                Row(children: [
                  Expanded(child: DropdownButtonFormField<int>(
                    value: _month,
                    decoration: const InputDecoration(labelText: 'Month', isDense: true),
                    items: List.generate(12, (i) => DropdownMenuItem(value: i+1, child: Text(_months[i], style: const TextStyle(fontSize: 13)))),
                    onChanged: (v) => setState(() => _month = v!),
                  )),
                  const SizedBox(width: 10),
                  Expanded(child: TextFormField(
                    initialValue: _year.toString(),
                    decoration: const InputDecoration(labelText: 'Year', isDense: true),
                    keyboardType: TextInputType.number,
                    onChanged: (v) => setState(() => _year = int.tryParse(v) ?? _year),
                  )),
                ]),
                const SizedBox(height: 10),
                SegmentedButton<String>(
                  segments: const [
                    ButtonSegment(value: 'pending', label: Text('Pending', style: TextStyle(fontSize: 11))),
                    ButtonSegment(value: 'clientwise', label: Text('Client-wise', style: TextStyle(fontSize: 11))),
                    ButtonSegment(value: 'summary', label: Text('Summary', style: TextStyle(fontSize: 11))),
                  ],
                  selected: {_reportType},
                  onSelectionChanged: (s) => setState(() { _reportType = s.first; _generated = false; }),
                  style: ButtonStyle(padding: WidgetStateProperty.all(const EdgeInsets.symmetric(horizontal: 4))),
                ),
                const SizedBox(height: 12),
                Row(children: [
                  Expanded(child: ElevatedButton.icon(
                    onPressed: _generate,
                    icon: const Icon(Icons.bar_chart, size: 16),
                    label: const Text('Generate'),
                  )),
                  const SizedBox(width: 8),
                  OutlinedButton.icon(
                    onPressed: () {
                      final csv = _exportCSV();
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('CSV ready (${_buildItems().length} records) — share via below'), action: SnackBarAction(label: 'OK', onPressed: (){})),
                      );
                      // In real app: save to file and use share_plus
                    },
                    icon: const Icon(Icons.download, size: 16),
                    label: const Text('CSV'),
                  ),
                ]),
              ],
            ),
          ),
        ),
        if (_loading) const Center(child: Padding(padding: EdgeInsets.all(24), child: CircularProgressIndicator())),
        if (_generated && !_loading) ...[
          const SizedBox(height: 10),
          if (_reportType == 'summary') ...[
            _SummaryCard(total: items.length, filed: filed, pending: pending, overdue: overdue, month: _months[_month-1], year: _year),
          ] else if (_reportType == 'pending') ...[
            Text('Pending Returns — ${_months[_month-1]} $_year',
                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
            const SizedBox(height: 8),
            if (items.where((i) => i.gstReturn.status != FilingStatus.filed && i.gstReturn.status != FilingStatus.notApplicable).isEmpty)
              Card(child: Padding(padding: const EdgeInsets.all(20),
                  child: Center(child: Text('No pending returns', style: TextStyle(color: scheme.outline)))))
            else
              ...items.where((i) => i.gstReturn.status != FilingStatus.filed && i.gstReturn.status != FilingStatus.notApplicable)
                  .map((i) => _ReportRow(item: i)),
          ] else ...[
            Text('Client-wise Status — ${_months[_month-1]} $_year',
                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
            const SizedBox(height: 8),
            ..._clients.map((c) {
              final cItems = items.where((i) => i.client.id == c.id).toList();
              if (cItems.isEmpty) return const SizedBox();
              final cFiled = cItems.where((i) => i.gstReturn.status == FilingStatus.filed).length;
              final pct = cItems.isEmpty ? 0.0 : cFiled / cItems.length;
              return Card(
                margin: const EdgeInsets.only(bottom: 10),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(c.name, style: const TextStyle(fontWeight: FontWeight.w600)),
                        Text(c.gstin, style: TextStyle(fontFamily: 'monospace', fontSize: 11, color: scheme.onSurface.withOpacity(0.5))),
                      ])),
                      Text('$cFiled/${cItems.length}', style: TextStyle(fontFamily: 'monospace', fontSize: 12, color: scheme.primary)),
                    ]),
                    const SizedBox(height: 6),
                    LinearProgressIndicator(value: pct, backgroundColor: scheme.outline.withOpacity(0.2)),
                    const SizedBox(height: 8),
                    ...cItems.map((i) => Padding(
                      padding: const EdgeInsets.symmetric(vertical: 2),
                      child: Row(children: [
                        Text(i.gstReturn.returnType, style: const TextStyle(fontFamily: 'monospace', fontSize: 11, fontWeight: FontWeight.w600)),
                        const Spacer(),
                        _StatusDot(i.gstReturn),
                      ]),
                    )),
                  ]),
                ),
              );
            }),
          ],
        ],
      ],
    );
  }
}

class _SummaryCard extends StatelessWidget {
  final int total, filed, pending, overdue;
  final String month;
  final int year;
  const _SummaryCard({required this.total, required this.filed, required this.pending, required this.overdue, required this.month, required this.year});

  @override
  Widget build(BuildContext context) {
    final pct = total > 0 ? filed / total : 0.0;
    final scheme = Theme.of(context).colorScheme;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('$month $year — Compliance Summary', style: const TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 12),
          GridView.count(
            crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: 8, mainAxisSpacing: 8, childAspectRatio: 2,
            children: [
              _miniStat('Total', total, scheme.primary),
              _miniStat('Filed', filed, const Color(0xFF22C55E)),
              _miniStat('Pending', pending, const Color(0xFFF59E0B)),
              _miniStat('Overdue', overdue, const Color(0xFFEF4444)),
            ],
          ),
          const SizedBox(height: 10),
          Row(children: [
            Text('Compliance Rate: ', style: TextStyle(fontSize: 13, color: scheme.onSurface.withOpacity(0.6))),
            Text('${(pct * 100).toStringAsFixed(0)}%', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          ]),
          const SizedBox(height: 6),
          LinearProgressIndicator(value: pct, backgroundColor: scheme.outline.withOpacity(0.2), color: const Color(0xFF22C55E)),
        ]),
      ),
    );
  }

  Widget _miniStat(String label, int val, Color color) => Container(
    padding: const EdgeInsets.all(8),
    decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(8),
        border: Border(top: BorderSide(color: color, width: 2))),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('$val', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: color)),
      Text(label, style: TextStyle(fontSize: 11, color: color.withOpacity(0.7))),
    ]),
  );
}

class _ReportRow extends StatelessWidget {
  final _ReportItem item;
  const _ReportRow({required this.item});

  @override
  Widget build(BuildContext context) {
    final r = item.gstReturn;
    final scheme = Theme.of(context).colorScheme;
    return Card(
      margin: const EdgeInsets.only(bottom: 6),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        child: Row(children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(item.client.name, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
            Text('${r.returnType}  •  ${DateFormat('dd MMM').format(r.dueDate)}',
                style: TextStyle(fontFamily: 'monospace', fontSize: 11, color: scheme.onSurface.withOpacity(0.5))),
          ])),
          _StatusDot(r),
        ]),
      ),
    );
  }
}

class _StatusDot extends StatelessWidget {
  final GstReturn r;
  const _StatusDot(this.r);

  @override
  Widget build(BuildContext context) {
    Color color;
    String label;
    if (r.isOverdue) { color = const Color(0xFFEF4444); label = 'Overdue'; }
    else if (r.status == FilingStatus.filed) { color = const Color(0xFF22C55E); label = 'Filed'; }
    else if (r.status == FilingStatus.inProgress) { color = const Color(0xFF4F8EF7); label = 'In Progress'; }
    else { color = const Color(0xFFF59E0B); label = 'Pending'; }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(label, style: TextStyle(fontSize: 11, color: color, fontWeight: FontWeight.w600)),
    );
  }
}

class _ReportItem {
  final Client client;
  final GstReturn gstReturn;
  _ReportItem({required this.client, required this.gstReturn});
}
