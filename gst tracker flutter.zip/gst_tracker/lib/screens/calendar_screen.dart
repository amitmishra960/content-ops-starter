// calendar_screen.dart
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/client.dart';
import '../models/gst_return.dart';
import '../services/database_service.dart';
import '../services/due_date_service.dart';
import '../widgets/return_item_card.dart';

class CalendarScreen extends StatefulWidget {
  const CalendarScreen({super.key});
  @override
  State<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends State<CalendarScreen> {
  DateTime _focused = DateTime.now();
  DateTime? _selected;
  Map<DateTime, List<_Event>> _events = {};
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final clients = await DatabaseService.getClients();
    final allFilings = await DatabaseService.getAllFilings();
    final filingMap = {for (var f in allFilings) f.dbKey: f};
    final events = <DateTime, List<_Event>>{};

    for (final c in clients) {
      for (final r in DueDateService.getReturnsForClient(c)) {
        final f = filingMap[r.dbKey];
        if (f != null) { r.status = f.status; r.filingDate = f.filingDate; r.remarks = f.remarks; }
        final day = DateTime(r.dueDate.year, r.dueDate.month, r.dueDate.day);
        events.putIfAbsent(day, () => []).add(_Event(client: c, gstReturn: r));
      }
    }
    setState(() { _events = events; _loading = false; });
  }

  Color _dayColor(DateTime day) {
    final evts = _events[day] ?? [];
    if (evts.isEmpty) return Colors.transparent;
    if (evts.any((e) => e.gstReturn.isOverdue)) return const Color(0xFFEF4444);
    if (evts.any((e) => e.gstReturn.isDueSoon)) return const Color(0xFFF59E0B);
    if (evts.every((e) => e.gstReturn.status == FilingStatus.filed)) return const Color(0xFF22C55E);
    return const Color(0xFF4F8EF7);
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final now = DateTime.now();
    final first = DateTime(_focused.year, _focused.month, 1).weekday % 7;
    final daysInMonth = DateTime(_focused.year, _focused.month + 1, 0).day;
    final weekdays = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];

    final selectedEvents = _selected != null ? (_events[_selected] ?? []) : [];

    return _loading
        ? const Center(child: CircularProgressIndicator())
        : RefreshIndicator(
            onRefresh: _load,
            child: ListView(
              padding: const EdgeInsets.all(14),
              children: [
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            IconButton(
                              icon: const Icon(Icons.chevron_left),
                              onPressed: () => setState(() {
                                _focused = DateTime(_focused.year, _focused.month - 1);
                              }),
                            ),
                            Text(
                              DateFormat('MMMM yyyy').format(_focused),
                              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
                            ),
                            IconButton(
                              icon: const Icon(Icons.chevron_right),
                              onPressed: () => setState(() {
                                _focused = DateTime(_focused.year, _focused.month + 1);
                              }),
                            ),
                          ],
                        ),
                        Row(
                          children: weekdays.map((d) => Expanded(
                            child: Text(d, textAlign: TextAlign.center,
                                style: TextStyle(fontSize: 11, color: scheme.onSurface.withOpacity(0.4))),
                          )).toList(),
                        ),
                        const SizedBox(height: 4),
                        GridView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 7, mainAxisSpacing: 4, crossAxisSpacing: 4),
                          itemCount: first + daysInMonth,
                          itemBuilder: (context, i) {
                            if (i < first) return const SizedBox();
                            final day = i - first + 1;
                            final date = DateTime(_focused.year, _focused.month, day);
                            final isToday = date.year == now.year && date.month == now.month && date.day == now.day;
                            final isSelected = _selected != null && date.isAtSameMomentAs(_selected!);
                            final color = _dayColor(date);
                            final hasEvents = (_events[date] ?? []).isNotEmpty;
                            return GestureDetector(
                              onTap: () => setState(() => _selected = hasEvents ? date : null),
                              child: Container(
                                decoration: BoxDecoration(
                                  color: isSelected ? color.withOpacity(0.25) : Colors.transparent,
                                  border: Border.all(
                                    color: isToday ? scheme.primary : (isSelected ? color : Colors.transparent),
                                    width: isToday || isSelected ? 1.5 : 0,
                                  ),
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text('$day', style: TextStyle(
                                      fontSize: 11,
                                      fontWeight: isToday ? FontWeight.w700 : FontWeight.normal,
                                      color: isToday ? scheme.primary : null,
                                    )),
                                    if (hasEvents) Container(
                                      width: 4, height: 4,
                                      decoration: BoxDecoration(color: color, shape: BoxShape.circle),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                        const SizedBox(height: 8),
                        // Legend
                        Wrap(
                          spacing: 12, runSpacing: 4,
                          children: [
                            _legend('Overdue', const Color(0xFFEF4444)),
                            _legend('Due Soon', const Color(0xFFF59E0B)),
                            _legend('Filed', const Color(0xFF22C55E)),
                            _legend('Upcoming', const Color(0xFF4F8EF7)),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                if (selectedEvents.isNotEmpty) ...[
                  const SizedBox(height: 10),
                  Text(
                    DateFormat('dd MMMM yyyy').format(_selected!),
                    style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
                  ),
                  const SizedBox(height: 8),
                  ...selectedEvents.map((e) => Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: ReturnItemCard(gstReturn: e.gstReturn, client: e.client, onUpdate: _load),
                  )),
                ],
              ],
            ),
          );
  }

  Widget _legend(String label, Color color) => Row(
    mainAxisSize: MainAxisSize.min,
    children: [
      Container(width: 8, height: 8, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
      const SizedBox(width: 4),
      Text(label, style: TextStyle(fontSize: 11, color: Theme.of(context).colorScheme.onSurface.withOpacity(0.5))),
    ],
  );
}

class _Event {
  final Client client;
  final GstReturn gstReturn;
  _Event({required this.client, required this.gstReturn});
}
