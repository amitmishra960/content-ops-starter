import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/client.dart';
import '../models/gst_return.dart';
import '../services/database_service.dart';
import '../services/due_date_service.dart';
import '../widgets/status_badge.dart';
import '../widgets/return_item_card.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  List<Client> _clients = [];
  List<_ReturnWithClient> _allReturns = [];
  String _filter = 'all';
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final clients = await DatabaseService.getClients();
    final allFilings = await DatabaseService.getAllFilings();
    final filingMap = {for (var f in allFilings) f.dbKey: f};

    final List<_ReturnWithClient> combined = [];
    for (final c in clients) {
      final returns = DueDateService.getReturnsForClient(c);
      for (final r in returns) {
        final filed = filingMap[r.dbKey];
        if (filed != null) {
          r.status = filed.status;
          r.filingDate = filed.filingDate;
          r.remarks = filed.remarks;
        }
        combined.add(_ReturnWithClient(client: c, gstReturn: r));
      }
    }
    setState(() {
      _clients = clients;
      _allReturns = combined;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    final scheme = Theme.of(context).colorScheme;
    final today = DateTime.now();

    int filedToday = 0, pending = 0, overdue = 0;
    for (final item in _allReturns) {
      final r = item.gstReturn;
      if (r.status == FilingStatus.filed &&
          r.filingDate != null &&
          DateFormat('yyyy-MM-dd').format(r.filingDate!) ==
              DateFormat('yyyy-MM-dd').format(today)) {
        filedToday++;
      }
      if (r.isOverdue) overdue++;
      else if (r.status == FilingStatus.pending || r.status == FilingStatus.inProgress) pending++;
    }

    final filtered = _allReturns.where((item) {
      final r = item.gstReturn;
      if (_filter == 'overdue') return r.isOverdue;
      if (_filter == 'soon') return r.isDueSoon;
      return r.status != FilingStatus.filed && r.status != FilingStatus.notApplicable;
    }).toList();

    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          // STATS GRID
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: 1.5,
            children: [
              _StatCard('Total Clients', _clients.length.toString(), scheme.primary, Icons.people),
              _StatCard('Filed Today', filedToday.toString(), const Color(0xFF22C55E), Icons.check_circle),
              _StatCard('Pending', pending.toString(), const Color(0xFFF59E0B), Icons.pending_actions),
              _StatCard('Overdue', overdue.toString(), const Color(0xFFEF4444), Icons.warning_amber),
            ],
          ),
          const SizedBox(height: 14),
          // MINI CALENDAR
          _MiniCalendar(returns: _allReturns),
          const SizedBox(height: 14),
          // FILTER CHIPS
          Row(children: [
            _filterChip('All', 'all'),
            const SizedBox(width: 6),
            _filterChip('Overdue', 'overdue'),
            const SizedBox(width: 6),
            _filterChip('Due in 3 days', 'soon'),
          ]),
          const SizedBox(height: 8),
          // RETURN LIST
          if (filtered.isEmpty)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(children: [
                  const Icon(Icons.check_circle_outline, size: 48, color: Color(0xFF22C55E)),
                  const SizedBox(height: 8),
                  Text('All caught up!', style: TextStyle(color: scheme.onSurface.withOpacity(0.5))),
                ]),
              ),
            )
          else
            ...filtered.take(20).map((item) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: ReturnItemCard(
                gstReturn: item.gstReturn,
                client: item.client,
                onUpdate: _load,
              ),
            )),
        ],
      ),
    );
  }

  Widget _filterChip(String label, String value) {
    final active = _filter == value;
    return FilterChip(
      label: Text(label),
      selected: active,
      onSelected: (_) => setState(() => _filter = value),
      showCheckmark: false,
    );
  }
}

class _ReturnWithClient {
  final Client client;
  final GstReturn gstReturn;
  _ReturnWithClient({required this.client, required this.gstReturn});
}

class _StatCard extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  final IconData icon;
  const _StatCard(this.label, this.value, this.color, this.icon);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(12),
        border: Border(top: BorderSide(color: color, width: 3)),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 4)],
      ),
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(children: [
            Icon(icon, color: color, size: 18),
            const Spacer(),
          ]),
          Text(value, style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: color)),
          Text(label, style: TextStyle(fontSize: 11, color: Theme.of(context).colorScheme.onSurface.withOpacity(0.5))),
        ],
      ),
    );
  }
}

class _MiniCalendar extends StatelessWidget {
  final List<_ReturnWithClient> returns;
  const _MiniCalendar({required this.returns});

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final first = DateTime(now.year, now.month, 1).weekday % 7;
    final daysInMonth = DateTime(now.year, now.month + 1, 0).day;

    // Build map of days with event colors
    Map<int, Color> dayColors = {};
    for (final item in returns) {
      final r = item.gstReturn;
      if (r.dueDate.year == now.year && r.dueDate.month == now.month) {
        final day = r.dueDate.day;
        Color c;
        if (r.isOverdue) c = const Color(0xFFEF4444);
        else if (r.isDueSoon) c = const Color(0xFFF59E0B);
        else if (r.status == FilingStatus.filed) c = const Color(0xFF22C55E);
        else c = const Color(0xFF4F8EF7);
        // Prioritize: overdue > soon > others
        if (!dayColors.containsKey(day) || c == const Color(0xFFEF4444)) {
          dayColors[day] = c;
        }
      }
    }

    final weekdays = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              DateFormat('MMMM yyyy').format(now),
              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
            ),
            const SizedBox(height: 8),
            Row(children: weekdays.map((d) => Expanded(
              child: Text(d, textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 10, color: Theme.of(context).colorScheme.onSurface.withOpacity(0.4))),
            )).toList()),
            const SizedBox(height: 4),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 7, mainAxisSpacing: 2, crossAxisSpacing: 2),
              itemCount: first + daysInMonth,
              itemBuilder: (context, i) {
                if (i < first) return const SizedBox();
                final day = i - first + 1;
                final isToday = day == now.day;
                final color = dayColors[day];
                return Container(
                  decoration: BoxDecoration(
                    color: isToday ? Theme.of(context).colorScheme.primary.withOpacity(0.2) : Colors.transparent,
                    border: isToday ? Border.all(color: Theme.of(context).colorScheme.primary, width: 1.5) : null,
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('$day', style: TextStyle(
                        fontSize: 10,
                        fontWeight: isToday ? FontWeight.w700 : FontWeight.normal,
                        color: color ?? (isToday ? Theme.of(context).colorScheme.primary : null),
                      )),
                      if (color != null) Container(width: 4, height: 4,
                          decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
                    ],
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
