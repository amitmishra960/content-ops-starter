import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/client.dart';
import '../models/gst_return.dart';
import '../services/database_service.dart';
import '../services/due_date_service.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});
  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  List<_Alert> _alerts = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final clients = await DatabaseService.getClients();
    final allFilings = await DatabaseService.getAllFilings();
    final filingMap = {for (var f in allFilings) f.dbKey: f};
    final alerts = <_Alert>[];
    final now = DateTime.now();

    for (final c in clients) {
      for (final r in DueDateService.getReturnsForClient(c)) {
        final f = filingMap[r.dbKey];
        if (f != null) { r.status = f.status; r.filingDate = f.filingDate; r.remarks = f.remarks; }
        if (r.status == FilingStatus.filed || r.status == FilingStatus.notApplicable) continue;
        final diff = r.dueDate.difference(now).inDays;
        if (diff < 0) {
          alerts.add(_Alert(client: c, gstReturn: r, diff: diff.abs(), type: 'overdue'));
        } else if (diff <= 7) {
          alerts.add(_Alert(client: c, gstReturn: r, diff: diff, type: diff <= 1 ? 'urgent' : diff <= 3 ? 'warning' : 'info'));
        }
      }
    }
    alerts.sort((a, b) => a.diff.compareTo(b.diff));
    setState(() { _alerts = alerts; _loading = false; });
  }

  @override
  Widget build(BuildContext context) {
    return _loading
        ? const Center(child: CircularProgressIndicator())
        : _alerts.isEmpty
            ? Center(
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  const Icon(Icons.notifications_none, size: 64, color: Color(0xFF22C55E)),
                  const SizedBox(height: 12),
                  const Text('No upcoming alerts', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 4),
                  Text('All returns are up to date!', style: TextStyle(color: Theme.of(context).colorScheme.outline)),
                ]),
              )
            : RefreshIndicator(
                onRefresh: _load,
                child: ListView.builder(
                  padding: const EdgeInsets.all(14),
                  itemCount: _alerts.length + 1,
                  itemBuilder: (context, i) {
                    if (i == 0) return _InfoBanner();
                    final a = _alerts[i - 1];
                    return _AlertCard(alert: a);
                  },
                ),
              );
  }
}

class _InfoBanner extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Theme.of(context).colorScheme.primary.withOpacity(0.3)),
      ),
      child: Row(children: [
        Icon(Icons.info_outline, size: 16, color: Theme.of(context).colorScheme.primary),
        const SizedBox(width: 8),
        Expanded(child: Text('Showing returns due within 7 days or overdue.',
            style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.primary))),
      ]),
    );
  }
}

class _AlertCard extends StatelessWidget {
  final _Alert alert;
  const _AlertCard({required this.alert});

  Future<void> _openWhatsApp(BuildContext context) async {
    final c = alert.client;
    final r = alert.gstReturn;
    final msg = Uri.encodeComponent(
      'Dear ${c.name},\n\n'
      'Reminder: Your ${r.returnType} return is due on '
      '${DateFormat('dd MMM yyyy').format(r.dueDate)}.\n\n'
      'Please share required documents at the earliest to avoid penalties.\n\n'
      'Thank you\n'
      'Your CA',
    );
    final url = Uri.parse('https://wa.me/${c.mobile}?text=$msg');
    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('WhatsApp not available')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final colors = {
      'overdue': const Color(0xFFEF4444),
      'urgent': const Color(0xFFEF4444),
      'warning': const Color(0xFFF59E0B),
      'info': const Color(0xFF4F8EF7),
    };
    final icons = {
      'overdue': '🔴', 'urgent': '🚨', 'warning': '⚠️', 'info': '📌',
    };
    final color = colors[alert.type] ?? scheme.primary;
    final label = alert.type == 'overdue'
        ? 'Overdue by ${alert.diff} day(s)'
        : 'Due in ${alert.diff} day(s) — ${DateFormat('dd MMM yyyy').format(alert.gstReturn.dueDate)}';

    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: Container(
        decoration: BoxDecoration(
          border: Border(left: BorderSide(color: color, width: 4)),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Text(icons[alert.type] ?? '📌', style: const TextStyle(fontSize: 24)),
              const SizedBox(width: 10),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(alert.client.name, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                  Text(alert.gstReturn.returnType, style: TextStyle(fontFamily: 'monospace', fontSize: 12, color: color, fontWeight: FontWeight.w700)),
                  Text(label, style: TextStyle(fontSize: 12, color: scheme.onSurface.withOpacity(0.6))),
                ]),
              ),
              GestureDetector(
                onTap: () => _openWhatsApp(context),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: const Color(0xFF25D366),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Row(mainAxisSize: MainAxisSize.min, children: [
                    Text('💬', style: TextStyle(fontSize: 14)),
                    SizedBox(width: 4),
                    Text('WA', style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700)),
                  ]),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Alert {
  final Client client;
  final GstReturn gstReturn;
  final int diff;
  final String type;
  _Alert({required this.client, required this.gstReturn, required this.diff, required this.type});
}
