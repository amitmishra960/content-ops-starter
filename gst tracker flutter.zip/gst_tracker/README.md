# GST Return Tracker — Flutter Android App

A complete offline GST Return Tracking application for Chartered Accountants and Tax Consultants.

---

## 📱 Features

### Client Management
- Add, Edit, Delete clients with full GST profile
- Fields: Name, GSTIN, Trade Name, Business Type (Regular/Composition/QRMP), Mobile, Email, PAN, State, Registration Date
- Search & filter by name, GSTIN, or business type
- Client profile showing complete return history

### GST Return Due Dates (Auto-Calculated)
| Return | Due Date |
|--------|----------|
| GSTR-1 (Regular) | 11th of next month |
| GSTR-1 IFF (QRMP) | 13th of next month (non-quarter-end months) |
| GSTR-3B (Regular) | 20th of next month |
| GSTR-3B Quarterly (QRMP) | 22nd (Others) / 24th (Special States) after quarter end |
| GSTR-7, GSTR-8 | 10th of next month |
| CMP-08 (Composition) | 18th after quarter end |
| GSTR-4 (Composition) | 30th April next FY |
| GSTR-9 | 31st December next FY |
| GSTR-9C | 31st December next FY (Regular only) |

### Filing Status
- ⏳ Pending | 🔄 In Progress | ✅ Filed | — Not Applicable
- Add filing date and remarks per return
- WhatsApp reminder with pre-drafted message

### Dashboard
- Stats: Total Clients, Filed Today, Pending, Overdue
- Mini calendar with color-coded due dates
- Quick filter: All / Overdue / Due in 3 days

### Color Coding
- 🔴 **Red** — Overdue
- 🟡 **Yellow** — Due in ≤3 days
- 🟢 **Green** — Filed
- 🔵 **Blue** — Upcoming

### Notifications Tab
- All returns due within 7 days or overdue
- WhatsApp reminder button per return

### Reports
- Pending returns report by month
- Client-wise filing status
- Monthly compliance summary with rate %
- CSV export

### Security
- 4-digit PIN lock on app open
- Biometric (fingerprint) authentication
- Dark mode (default) / Light mode toggle

### Technical
- **Platform:** Android APK
- **Database:** SQLite (sqflite) — fully offline
- **Language:** Flutter/Dart
- **UI:** Material Design 3
- No login/signup required

---

## 🚀 Setup & Build

### Prerequisites
```bash
# Install Flutter SDK (latest stable)
# https://flutter.dev/docs/get-started/install

flutter --version  # Should be 3.x+
```

### Install & Run
```bash
cd gst_tracker

# Get dependencies
flutter pub get

# Run on connected Android device or emulator
flutter run

# Build release APK
flutter build apk --release

# APK location:
# build/app/outputs/flutter-apk/app-release.apk
```

### Build Debug APK (faster, for testing)
```bash
flutter build apk --debug
```

---

## 📁 Project Structure

```
lib/
├── main.dart                    # App entry, theme, PIN check
├── models/
│   ├── client.dart              # Client data model
│   └── gst_return.dart          # GST Return + FilingStatus
├── screens/
│   ├── home_screen.dart         # Bottom navigation host
│   ├── dashboard_screen.dart    # Stats, mini calendar, quick view
│   ├── clients_screen.dart      # Client list, add/edit/delete, profile
│   ├── returns_screen.dart      # All returns with filters
│   ├── calendar_screen.dart     # Month calendar with due dates
│   ├── notifications_screen.dart # Alerts for due/overdue returns
│   ├── reports_screen.dart      # Report generation + CSV export
│   └── pin_screen.dart          # PIN & biometric lock
├── services/
│   ├── database_service.dart    # SQLite CRUD operations
│   └── due_date_service.dart    # Auto due date calculations
└── widgets/
    ├── status_badge.dart        # Color-coded status chip
    └── return_item_card.dart    # Return card with update sheet
```

---

## 🔧 Customization

### Add More States for QRMP
Edit `due_date_service.dart` — the `state == 'special'` logic for 22nd/24th grouping.

### Change Notification Timing
The notification screen shows alerts for returns due within 7 days. Change the `<= 7` condition in `notifications_screen.dart`.

### Add More Return Types
Extend `DueDateService.getReturnsForClient()` in `due_date_service.dart`.

---

## 📦 Dependencies

```yaml
sqflite: ^2.3.3              # Local SQLite database
intl: ^0.19.0                # Date formatting
local_auth: ^2.3.0           # Fingerprint authentication
shared_preferences: ^2.2.3  # PIN storage, settings
url_launcher: ^6.3.0        # WhatsApp deep links
flutter_local_notifications  # Push notifications
```

---

## 🌐 Web Version
The `gst-tracker.html` file is a fully working Progressive Web App version of this tool. Open it in any browser — it works completely offline using localStorage. No server needed.

---

## 📄 License
Personal use for CA/Tax Consultants. Not for redistribution.
